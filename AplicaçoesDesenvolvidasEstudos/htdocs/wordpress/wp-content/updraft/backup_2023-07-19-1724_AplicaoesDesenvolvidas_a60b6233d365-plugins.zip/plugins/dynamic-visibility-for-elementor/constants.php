<?php
define( 'DVE_VERSION', '5.0.6' );
define( 'DVE_MINIMUM_ELEMENTOR_VERSION', '2.9.0' );
define( 'DVE_PRODUCT_NAME', 'Dynamic Visibility for Elementor' );
define( 'DVE_PRODUCT_NAME_LONG', 'Dynamic Visibility for Elementor' );
