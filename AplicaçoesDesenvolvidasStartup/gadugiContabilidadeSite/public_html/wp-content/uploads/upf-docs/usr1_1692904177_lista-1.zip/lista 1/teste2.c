#include<stdio.h>
#include<stdlib.h>

int main()
{
    float base = 3.5;
    float altura = 2.0;
    float area = base * altura;
    printf("\nUm retangulo de base igual a %f", base);
    printf("\n e altura igual a %f", altura);
    printf("\n tem um area de %f", area);
    return 0;

}