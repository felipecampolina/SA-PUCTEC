#include<stdio.h>
#include<stdlib.h>

int main()
{
    float base = 7.0;
    float perimetro = base *4;
    printf("O perimetro de um quadrado de base %f",base);
    printf(" e igual a %f",perimetro);
}