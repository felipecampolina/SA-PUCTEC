#include<stdio.h>
#include<stdlib.h>

int main()
{
    float c = 37.77777;
    float far = c * 1.8 + 32;
    printf("A temperatura em graus F e %f",far );
}