#include <stdio.h>
#include <stdlib.h>

int main ()
{
    float altura = 1.75;
    float peso = (72.7 * altura) - 58;
    printf("O peso ideal e %f",peso);
}