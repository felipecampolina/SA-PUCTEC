#include<stdio.h>
#include<stdlib.h>

int main()
{
    float raio = 1;
    float area = 3.14 * (raio * raio);
    
    printf("A area de um circulo de base %f",raio);
    printf(" e igual a %f",area);
}