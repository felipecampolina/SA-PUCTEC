#include<stdio.h>
#include<stdlib.h>

int main()
{
    float base = 10.0;
    float area = base * base;
    printf("A area de um quadrado de base %f",base);
    printf(" e igual a %f",area);
}